A complete build with the following changes
Changes
=======
1. Translation in main POS screen.
2. Few bug fixes
